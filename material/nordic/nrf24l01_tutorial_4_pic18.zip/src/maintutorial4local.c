/*****************************************************************************
*
* File: maintutorial4local.c
* 
* Copyright S. Brennen Ball, 2007
* 
* The author provides no guarantees, warantees, or promises, implied or
*	otherwise.  By using this software you agree to indemnify the author
* 	of any damages incurred by using it.
* 
*****************************************************************************/

//This code depends on a clock frequency of 40 MHz (I use a 10 MHz crystal and
//  the PLL.  If you are using a slower clock, then you must change the SPI and
//  UART rates, as well as the delay lengths in delays.c

#include <p18f452.h>
#include <stdio.h>
#include <usart.h>
#include <spi.h>
#include "delays.h"
#include "nrf24l01.h"
#include "arc4.h"

void Initialize(void);
void InitializeIO(void);

void ToggleLED(void); //toggle the current state of the on-board LED

#define keylen	3 //length of the key
unsigned char key[keylen] = {'K', 'e', 'y'}; //bytes of the key
		
//main routine
void main(void)
{
	unsigned int i; //general counter variable
	unsigned char curseq = 0; //keeps the current expected packet number
	unsigned char data[2]; //array to hold the encrypted byte and packet count
	
	Initialize(); //initialize IO, UART, SPI, set up nRF24L01 as TX, execute KSA
	
	while(1)
	{
		//wait until a packet has been received		
		while(!(nrf24l01_irq_pin_active() && nrf24l01_irq_rx_dr_active()));
		
		nrf24l01_irq_clear_all(); //clear all interrupts in the 24L01
		nrf24l01_read_rx_payload(data, 2); //get the payload into data

		//printf doesn't print the leading 0 if a hex number is less than 0x10, so print it manually
		if(data[0] < 0x10)
			printf("0");
		
		printf("%x: ", data[0]); //print out the received encrypted character
		
		//catch up to the correct location in the S array by executing the PRGA
		if(data[1] != curseq)
		{
			for(i = 0; i < data[1] - curseq; i++)
				arc4_get_prga_byte();
		}
		
		arc4_decrypt(data, 1); //decrypt the data received
		printf("%c\r\n", data[0]); //print out the decrypted character

		curseq = data[1] + 1; //increase the value of the expected next packet
		
		ToggleLED(); //toggle the on-board LED as visual indication that the loop has completed
	}
}

//initialize routine
void Initialize(void)
{
	InitializeIO(); //set up IO (directions and functions)
	OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF & USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX & USART_BRGH_HIGH, 21); //open UART
	OpenSPI(SPI_FOSC_16, MODE_00, SMPMID); //open SPI1
	nrf24l01_initialize_debug(true, 2, false); //initialize the 24L01 to the debug configuration asRX, 2 data bytes, and auto-ack disabled
	arc4_initialize_ksa(key, keylen); //execute the KSA
}

//initialize IO pins
void InitializeIO(void)
{
	ADCON1 = 0x7; //disable AD converter functionality on PORTA
	TRISAbits.TRISA0 = 0; //make PORTA.0 an output to control LED
	PORTAbits.RA0 = 1; //turn on LED
	
	TRISBbits.TRISB0 = 1; //make sure that PORTB.0 is input since it is IRQ pin
	
	TRISC = 0x90; //make CSN, CE, SCK, MOSI (SDO), and TX outputs
	PORTC = 0x01; //set CSN bit
}

//toggles on-board LED
void ToggleLED(void)
{
	PORTAbits.RA0 = ~PORTAbits.RA0; //toggle the bit that controls the LED
}
