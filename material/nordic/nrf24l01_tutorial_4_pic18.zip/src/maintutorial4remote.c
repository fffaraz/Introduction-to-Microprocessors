/*****************************************************************************
*
* File: maintutorial4remote.c
* 
* Copyright S. Brennen Ball, 2007
* 
* The author provides no guarantees, warantees, or promises, implied or
*	otherwise.  By using this software you agree to indemnify the author
* 	of any damages incurred by using it.
* 
*****************************************************************************/

//This code depends on a clock frequency of 40 MHz (I use a 10 MHz crystal and
//  the PLL.  If you are using a slower clock, then you must change the SPI and
//  UART rates, as well as the delay lengths in delays.c

#include <p18f452.h>
#include <stdio.h>
#include <usart.h>
#include <spi.h>
#include "delays.h"
#include "nrf24l01.h"
#include "arc4.h"

void Initialize(void);
void InitializeIO(void);

void ToggleLED(void); //toggle the current state of the on-board LED

#define keylen	3 //length of the key
unsigned char key[keylen] = {'K', 'e', 'y'}; //bytes of the key
		
//main routine
void main(void)
{
	unsigned char cur_letter = 'a'; //the letter we're going to send
	unsigned char data[2]; //array to hold the encrypted byte and packet count
	
	data[1] = 0; //initialize packet count
	
	Initialize(); //initialize IO, UART, SPI, set up nRF24L01 as RX, execute KSA
	
	while(1)
	{		
		DelayS(1); //delay 1 second between each letter
		
		data[0] = cur_letter; //set up data to be sent
		arc4_encrypt(data, 1); //encrypt the data

		nrf24l01_write_tx_payload(data, 2, true); //transmit encrypted byte and counter
		
		//wait for the packet to be sent
		while(!(nrf24l01_irq_pin_active() && nrf24l01_irq_tx_ds_active()));
		
		nrf24l01_irq_clear_all(); //clear all interrupts in the 24L01
		
		//go to the next character in the alphabet unless we're at z
		if(cur_letter != 'z')
			cur_letter++;
		else
			cur_letter = 'a';
			
		data[1]++; //increment the packet count

		ToggleLED(); //toggle the on-board LED as visual indication that the loop has completed
	}
}

//initialize routine
void Initialize(void)
{
	InitializeIO(); //set up IO (directions and functions)
	OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF & USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX & USART_BRGH_HIGH, 21); //open UART
	OpenSPI(SPI_FOSC_16, MODE_00, SMPMID); //open SPI1
	nrf24l01_initialize_debug(false, 2, false); //initialize the 24L01 to the debug configuration as TX, 14 data bytes, and auto-ack disabled
	arc4_initialize_ksa(key, keylen); //execute the KSA
}

//initialize IO pins
void InitializeIO(void)
{
	ADCON1 = 0x7; //disable AD converter functionality on PORTA
	TRISAbits.TRISA0 = 0; //make PORTA.0 an output to control LED
	PORTAbits.RA0 = 1; //turn on LED
	
	TRISBbits.TRISB0 = 1; //make sure that PORTB.0 is input since it is IRQ pin
	
	TRISC = 0x90; //make CSN, CE, SCK, MOSI (SDO), and TX outputs
	PORTC = 0x01; //set CSN bit
}

//toggles on-board LED
void ToggleLED(void)
{
	PORTAbits.RA0 = ~PORTAbits.RA0; //toggle the bit that controls the LED
}
