/*****************************************************************************
*
* File: maintutorial1local.c
* 
* Copyright S. Brennen Ball, 2007
* 
* The author provides no guarantees, warantees, or promises, implied or
*	otherwise.  By using this software you agree to indemnify the author
* 	of any damages incurred by using it.
* 
*****************************************************************************/

//This code depends on a clock frequency of 40 MHz (I use a 10 MHz crystal and
//  the PLL.  If you are using a slower clock, then you must change the SPI and
//  UART rates, as well as the delay lengths in delays.c

#include <p18f452.h>
#include <stdio.h>
#include <usart.h>
#include <spi.h>
#include "delays.h"
#include "nrf24l01.h"

void Initialize(void);
void InitializeIO(void);

void ToggleLED(void); //toggle the current state of the on-board LED
bool Ping(void); //send and receive packet

#define NUM_PINGS	5 //number of times to ping each channel
#define PING_DELAY	2 //seconds to wait between pings

//main routine
void main(void) 
{		
	unsigned char i, j; //inner and outer loop variables
	unsigned char pipe_count[6]; //stores successful pings
	unsigned char tx_addr[5]; //temporary variable to hold TX address for current pipe
	unsigned int total; //temporary variable to hold the total successful pings
	
	Initialize(); //initialize PLL, IO, UART, SPI, set up nRF24L01 as TX

	//main program loop
	while(1)
	{
		//clear successful pings
		for(i = 0; i < 6; i++)
			pipe_count[i] = 0;
		
		//announce the process is beginning
		printf("Testing link:\r\n");
		
		//ping all 6 ports
		for(i = 0; i < 6; i++)
		{	
			//set the TX address for the pipe with the same number as the iteration
			switch(i)
			{
				case 0: //setup TX address as default RX address for pipe 0 (E7:E7:E7:E7:E7)
					tx_addr[0] = tx_addr[1] = tx_addr[2] = tx_addr[3] = tx_addr[4] = nrf24l01_RX_ADDR_P0_B0_DEFAULT_VAL;
					nrf24l01_set_tx_addr(tx_addr, 5);
					break;
				case 1: //setup TX address as default RX address for pipe 1 (C2:C2:C2:C2:C2)
					tx_addr[0] = tx_addr[1] = tx_addr[2] = tx_addr[3] = tx_addr[4] = nrf24l01_RX_ADDR_P1_B0_DEFAULT_VAL;
					nrf24l01_set_tx_addr(tx_addr, 5);
					break;
				case 2: //setup TX address as default RX address for pipe 2 (C2:C2:C2:C2:C3)
					tx_addr[0] = nrf24l01_RX_ADDR_P2_DEFAULT_VAL;
					nrf24l01_set_tx_addr(tx_addr, 1);
					break;
				case 3: //setup TX address as default RX address for pipe 3 (C2:C2:C2:C2:C4)
					tx_addr[0] = nrf24l01_RX_ADDR_P3_DEFAULT_VAL;
					nrf24l01_set_tx_addr(tx_addr, 1);
					break;
				case 4: //setup TX address as default RX address for pipe 4 (C2:C2:C2:C2:C5)
					tx_addr[0] = nrf24l01_RX_ADDR_P4_DEFAULT_VAL;
					nrf24l01_set_tx_addr(tx_addr, 1);
					break;
				case 5: //setup TX address as default RX address for pipe 5 (C2:C2:C2:C2:C6)
					tx_addr[0] = nrf24l01_RX_ADDR_P5_DEFAULT_VAL;
					nrf24l01_set_tx_addr(tx_addr, 1);
					break;
			}

			//ping the pipe NUM_PINGS times
			//if the ping is successful (returns true), increment the pipe_count variable for this pipe
			for(j = 0; j < NUM_PINGS; j++)
				if(Ping())
					pipe_count[i]++;
			
			//output stats for this pipe		
			printf("  pinging pipe %u (%x:%x:%x:%x:%x): %u/%u (%u%%)\r\n", i, tx_addr[4], tx_addr[3], tx_addr[2], tx_addr[1], tx_addr[0], pipe_count[i], NUM_PINGS, ((unsigned int)pipe_count[i] * 100)/NUM_PINGS);
		}
		
		//find the total number of successful pings, and then output overall statistics
		total = pipe_count[0] + pipe_count[1] + pipe_count[2] + pipe_count[3] + pipe_count[4] + pipe_count[5];
		printf("  TOTAL: %u/%u (%u%%)\r\n\r\n", total, NUM_PINGS * 6, (total * 100)/(NUM_PINGS * 6));
									
		ToggleLED(); //toggle the on-board LED as visual indication that the loop has completed
		
		DelayS(PING_DELAY); //wait specified number of seconds until the next set of pings (default is 2 seconds)
	}
}

//ping the current pipe with one byte of data
bool Ping(void)
{
	unsigned char data = 0xFF; //register to hold byte sent and received
	unsigned int count; //counter for for loop
	
	nrf24l01_write_tx_payload(&data, 1, true); //transmit received char over RF

	//wait until the packet has been sent or the maximum number of retries has been reached
	while(!(nrf24l01_irq_pin_active() && nrf24l01_irq_tx_ds_active()));

	nrf24l01_irq_clear_all(); //clear all interrupts in the 24L01
	nrf24l01_set_as_rx(true); //change the device to an RX to get the character back from the other 24L01

	//wait a while to see if we get the data back (change the loop maximum and the lower if
	//  argument (should be loop maximum - 1) to lengthen or shorten this time frame
	for(count = 0; count < 20000; count++)
	{
		//check to see if the data has been received.  if so, get the data and exit the loop.
		//  if the loop is at its last count, assume the packet has been lost and set the data
		//  to go to the UART to "?".  If neither of these is true, keep looping.
		if((nrf24l01_irq_pin_active() && nrf24l01_irq_rx_dr_active()))
		{
			nrf24l01_read_rx_payload(&data, 1); //get the payload into data
			break;
		}
		
		//if loop is on its last iteration, assume packet has been lost.
		if(count == 19999)
			data = 0;
	}
	
	nrf24l01_irq_clear_all(); //clear interrupts again

	DelayUS(130); //wait for receiver to come from standby to RX
	nrf24l01_set_as_tx(); //resume normal operation as a TX

	//if the packet came back correctly, return true...otherwise, return false
	if(data == 0xFF)
		return true;
	else
		return false;
}

//initialize routine
void Initialize(void)
{
	InitializeIO(); //set up IO (directions and functions)
	OpenUSART (USART_TX_INT_OFF & USART_RX_INT_OFF & USART_ASYNCH_MODE & USART_EIGHT_BIT & USART_CONT_RX & USART_BRGH_LOW, 64); //open UART
	OpenSPI(SPI_FOSC_16, MODE_00, SMPMID); //open SPI1
	nrf24l01_initialize_debug(false, 1, false); //initialize the 24L01 to the debug configuration as TX, 1 data byte, and auto-ack disabled
}

//initialize IO pins
void InitializeIO(void)
{
	ADCON1 = 0x7; //disable AD converter functionality on PORTA
	TRISAbits.TRISA0 = 0; //make PORTA.0 an output to control LED
	PORTAbits.RA0 = 1; //turn on LED
	
	TRISBbits.TRISB0 = 1; //make sure that PORTB.0 is input since it is IRQ pin
	
	TRISC = 0x91; //make CSN, CE, SCK, MOSI (SDO), and TX outputs
	PORTC = 0x04; //set CSN bit
}	

//toggles on-board LED
void ToggleLED(void)
{
	PORTAbits.RA0 = ~PORTAbits.RA0;
}	
	