#ifndef _INCFILES_INCLUDED
#define _INCFILES_INCLUDED

#include <ioavr.h>
#include <inavr.h>
#include <ctype.h>
#include "main.h"
#include "spi.h"
#include "USART2.h"

#endif
